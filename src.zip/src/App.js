
import './App.css';
import Nav from './Nav/Nav';
import Section from './Section/Section';

function App() {
  return (
    <div className="App">
      
   <Nav/>
   <Section/>
    </div>
  );
}

export default App;
