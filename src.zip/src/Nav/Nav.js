import React from "react";
import './Nav.css'; 
function Nav() {
  return (
    <div>
      <div className="nav">M.O.Z.A.N.T.A</div>
    </div>
  );
}

export default Nav;
